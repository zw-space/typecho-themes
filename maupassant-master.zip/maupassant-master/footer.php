		</div>
    </div>
</div>
<footer id="footer">
	<div class="container">
		&copy; <?php echo date('Y'); ?> <a rel="nofollow" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>. 模板由<a href="http://pagecho.com">cho</a>制作.
	</div>
</footer>
<?php $this->footer(); ?>
</body>
</html>
